"""Same-frame numeric checks and balanced real-camera-background benchmarks."""
import hashlib
import json
from pathlib import Path
import platform
import statistics
import sys
import threading
import time
import traceback
import types
import uuid
import zipfile
import numpy as np

HERE = Path(__file__).resolve().parent


def compare(actual, expected, atol=1e-4, rtol=1e-4):
    actual, expected = np.asarray(actual), np.asarray(expected)
    if actual.shape != expected.shape or not np.isfinite(actual).all() or not np.isfinite(expected).all():
        raise RuntimeError('Numeric shape/finite mismatch')
    delta = np.abs(actual.astype(np.float64)-expected.astype(np.float64))
    if np.any(delta > atol+rtol*np.abs(expected)):
        raise RuntimeError('Numeric mismatch: max_abs='+str(float(delta.max())))
    return float(delta.max()) if delta.size else 0.


def system_snapshot():
    import glob
    result = {}
    for pattern in ('/sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq',
                    '/sys/class/thermal/thermal_zone*/temp'):
        for name in glob.glob(pattern):
            try:
                result[name] = int(Path(name).read_text().strip())
            except (ValueError, OSError):
                pass
    return result


def compare_hands(actual, expected):
    actual, expected = np.asarray(actual), np.asarray(expected)
    if actual.shape != expected.shape:
        raise RuntimeError('Palm count or output shape changed')
    if not actual.size:
        return 0.
    # Bounding boxes and 7 landmarks are in source-image pixels. Scores are probabilities.
    coordinates = compare(actual[:, :18], expected[:, :18], atol=.02, rtol=0.)
    compare(actual[:, 18], expected[:, 18], atol=1e-5, rtol=0.)
    return coordinates


class Background:
    def __init__(self, cv):
        from board_server import BoardRuntime
        self.runtime = BoardRuntime(types.SimpleNamespace(meta={'name': 'Benchmark background'}), cv)

    def start(self):
        r = self.runtime
        r.begin = time.monotonic()
        r.threads = [threading.Thread(target=r.capture_loop, daemon=True),
                     threading.Thread(target=r.preview_loop, daemon=True)]
        for thread in r.threads:
            thread.start()
        deadline = time.monotonic()+30
        while time.monotonic() < deadline:
            if r.error or r.preview_stream_error:
                raise RuntimeError(r.error or r.preview_stream_error)
            if r.capture_count >= 3 and r.preview_encoded_count >= 2:
                return
            time.sleep(.03)
        raise RuntimeError('Camera startup timeout')

    def snapshot(self):
        r = self.runtime
        with r.lock:
            return dict(capture=r.capture_count, preview=r.preview_encoded_count,
                        error=r.error or r.preview_stream_error)

    def stop(self):
        r = self.runtime
        r.stop_event.set()
        for thread in r.threads:
            thread.join(timeout=5)
        status = self.snapshot()
        status['workers_still_alive'] = [t.name for t in r.threads if t.is_alive()]
        return status


def select(summary, quality):
    baseline = summary['baseline']['pipeline_ms']
    candidates = [name for name in summary if not name.startswith('cpu_') and quality.get(name, False)]
    if not candidates:
        return None
    best = min(candidates, key=lambda name: summary[name]['pipeline_ms'])
    return best if summary[best]['pipeline_ms'] <= baseline*.90 else 'baseline'


def run(root='/home/xilinx/jupyter_notebooks', repeats=6):
    if type(repeats) is not int or repeats < 6:
        raise ValueError('At least six measured samples per direction required')
    if platform.system() != 'Linux' or platform.machine().lower() not in ('aarch64', 'arm64'):
        raise RuntimeError('Run on the board')
    from setup_runtime import prepare, verify_app
    versions = prepare(root)
    root = Path(root)
    folder = HERE/'results'/('v3_'+uuid.uuid4().hex[:12])
    folder.mkdir(parents=True)
    report = dict(passed=False, board_tested=True, error=None, cleanup_errors=[],
                  versions=versions, samples=[], numeric_checks=[], blocks=[], kernel_restart_required=False,
                  scope='Same original FP32 models; same fixed frame; no skipped palm detection. '
                        'Real threaded capture+preview background. Timing excludes HTTP/UI/hold gate. '
                        'FPGA v2 unchanged. CPU ORT full-model controls included.')
    base = background = None
    variants = {}
    previous_threads = None
    cv = None
    caught = None
    def save():
        (folder/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    from session_guard import exclusive_board_test
    with exclusive_board_test():
        try:
            from board_server import VisionBackend, check_camera_unused, load_cv
            from v3_runtime import Vision, ROUTES, verify_models
            check_camera_unused('/dev/video0')
            verify_models(root)
            cv = load_cv(root)
            previous_threads = cv.getNumThreads()
            accel = root/'gesture_block_accel_v2'
            base = VisionBackend(root, root/'gesture4_model_v2', accel, 'fpga_v2', cv_threads=4)
            variants = {name: Vision(base, root, accel, name) for name in ROUTES}
            report['package_manifest_sha256'] = hashlib.sha256((HERE/'manifest.json').read_bytes()).hexdigest()
            report['bit_sha256'] = hashlib.sha256((accel/'overlay/gesture_blocks56.bit').read_bytes()).hexdigest()
            report['model_sha256'] = base.meta['model_sha256']
            frames = [(p.name, cv.imread(str(p))) for p in sorted((HERE/'samples').glob('*.png'))]
            frames += [('black', np.zeros((480, 640, 3), np.uint8)),
                       ('gray', np.full((480, 640, 3), 127, np.uint8)),
                       ('noise', np.random.default_rng(20261101).integers(0, 256, (480, 640, 3), dtype=np.uint8))]
            # Compare raw palm tensors BEFORE NMS, decoded palm outputs, logits and scores.
            for index, (name, frame) in enumerate(frames):
                if frame is None:
                    raise RuntimeError('Invalid sample image: '+name)
                blob, _ = base.detector._preprocess(frame)
                base.detector.model.setInput(blob)
                palm_reference = base.detector.model.forward(base.detector.model.getUnconnectedOutLayersNames())
                hands = base.detector.infer(frame)
                classifier_input = base.classifier.preprocess(frame)
                expected_logits = variants['cpu_cv'].classifier.logits(classifier_input)
                for route, vision in variants.items():
                    delta = 0.
                    if route not in ('baseline', 'cpu_cv'):
                        vision.detector.model.setInput(blob)
                        outputs = vision.detector.model.forward(vision.detector.model.getUnconnectedOutLayersNames())
                        delta = max(compare(a, b, atol=1e-3, rtol=1e-4)
                                    for a, b in zip(outputs, palm_reference))
                    hand_error = compare_hands(vision.detector.infer(frame), hands)
                    logits = vision.classifier.logits(classifier_input)
                    logit_error = compare(logits, expected_logits)
                    if int(logits.argmax()) != int(expected_logits.argmax()):
                        raise RuntimeError('Class decision changed: '+name+' '+route)
                    expected_score = dict(base.classifier.topk(expected_logits, 4))
                    actual_score = dict(vision.classifier.topk(logits, 4))
                    compare([actual_score[k] for k in base.classifier.labels],
                            [expected_score[k] for k in base.classifier.labels])
                    report['numeric_checks'].append(dict(image=name, route=route, hands=len(hands),
                        palm_raw_max_abs=delta, palm_decoded_max_abs=hand_error, logits_max_abs=logit_error))
                print('Numeric', index+1, '/', len(frames), name, flush=True)
                save()
            fixed = cv.imread(str(HERE/'samples/fixed_hand.png'))
            reference = variants['cpu_cv'].classifier.logits(base.classifier.preprocess(fixed))
            reference_hands = base.detector.infer(fixed)
            if not len(reference_hands):
                raise RuntimeError('Fixed frame must contain a detected hand')
            report['fixed_frame_sha256'] = hashlib.sha256(fixed.tobytes()).hexdigest()
            background = Background(cv)
            background.start()
            order = list(ROUTES)
            for index, route in enumerate(order+list(reversed(order))):
                vision = variants[route]
                print('Benchmark', index+1, '/', len(order)*2, route, flush=True)
                block = dict(route=route, index=index+1, system_before=system_snapshot())
                # Warmup belongs to the same background load but is not timed.
                for _ in range(2):
                    vision.infer(fixed)
                before = background.snapshot()
                start = time.perf_counter()
                for sample in range(repeats):
                    completed = int(getattr(vision.classifier, 'fpga_completed_frames', 0))
                    began = time.perf_counter()
                    result = vision.infer(fixed)
                    elapsed = (time.perf_counter()-began)*1000
                    if not result['detected']:
                        raise RuntimeError('Same-frame detection changed')
                    expected = base.classifier.topk(reference, 3)
                    if result['label'] != expected[0][0]:
                        raise RuntimeError('Benchmark class changed')
                    compare([v for _, v in result['predictions']], [v for _, v in expected])
                    if vision.accelerator is not None and result['fpga_completed_frames'] != completed+1:
                        raise RuntimeError('FPGA command completion missing')
                    report['samples'].append(dict(route=route, block=index+1, sample=sample+1,
                        pipeline_ms=elapsed, detector_ms=result['detector_ms'], classifier_ms=result['classifier_ms'],
                        fpga_call_ms=result['fpga_call_ms'], fpga_completed=result['fpga_completed_frames']))
                    print(' ', sample+1, '/', repeats, round(elapsed, 2), 'ms', flush=True)
                duration = time.perf_counter()-start
                after = background.snapshot()
                if after['error']:
                    raise RuntimeError(after['error'])
                block.update(capture_hz=(after['capture']-before['capture'])/duration,
                             preview_hz=(after['preview']-before['preview'])/duration,
                             system_after=system_snapshot())
                report['blocks'].append(block)
                save()
            report['summary'] = {}
            quality = {}
            for route in ROUTES:
                rows = [r for r in report['samples'] if r['route'] == route]
                report['summary'][route] = {key: statistics.median(r[key] for r in rows)
                    for key in ('pipeline_ms', 'detector_ms', 'classifier_ms')}
                report['summary'][route]['samples'] = len(rows)
                quality[route] = all(b['capture_hz'] >= 10 and b['preview_hz'] >= 8
                                     for b in report['blocks'] if b['route'] == route)
            chosen = select(report['summary'], quality)
            report['selected_route'] = chosen
            report['background_quality'] = quality
            if chosen is not None:
                old = report['summary']['baseline']['pipeline_ms']
                new = report['summary'][chosen]['pipeline_ms']
                report['reduction_vs_v2_percent'] = 100*(1-new/old)
                report['noticeable_25percent_target_met'] = new <= old*.75
                best_cpu = min((n for n in ROUTES if n.startswith('cpu_') and quality[n]),
                               key=lambda n: report['summary'][n]['pipeline_ms'], default=None)
                report['fastest_cpu_route'] = best_cpu
                report['selected_fpga_vs_fastest_cpu_speedup'] = (
                    report['summary'][best_cpu]['pipeline_ms']/new if best_cpu else None)
            report['passed'] = True
        except BaseException as error:
            caught = error
            report['error'] = dict(message=repr(error), traceback=traceback.format_exc())
        finally:
            if background is not None:
                status = background.stop()
                report['camera_cleanup'] = status
                if status['workers_still_alive'] or status['error']:
                    report['cleanup_errors'].append(status)
                    report['kernel_restart_required'] = True
            if base is not None:
                try:
                    base.close()
                except BaseException as error:
                    report['cleanup_errors'].append(repr(error))
                    report['kernel_restart_required'] = True
            # Drop callbacks that reference their classifier and release idle ORT pools
            # before the subsequent live service constructs its own sessions.
            variants.clear()
            import gc
            gc.collect()
            if cv is not None and previous_threads is not None and not report['kernel_restart_required']:
                cv.setNumThreads(previous_threads)
            report['passed'] = report['passed'] and not report['cleanup_errors'] and report['error'] is None
            save()
            print('V3_VALIDATION_OK' if report['passed'] else 'V3_VALIDATION_FAILED', flush=True)
    if caught is not None:
        raise caught
    print(json.dumps(report.get('summary', {}), indent=2), flush=True)
    print('SELECTED FPGA ROUTE:', report.get('selected_route'), flush=True)
    print('25% latency reduction target:', report.get('noticeable_25percent_target_met'), flush=True)
    return report


def export_results():
    import board_server
    runtime = board_server._active_runtime
    if runtime is not None and any(t.is_alive() for t in runtime.threads):
        raise RuntimeError('Stop the server before packaging logs')
    target = HERE/'gesture_order_accel_v3_results.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for directory in ('results', 'logs'):
            for path in sorted((HERE/directory).rglob('*')):
                if path.is_file():
                    archive.write(path, path.relative_to(HERE).as_posix())
        for name in ('manifest.json', '00_start_v3.ipynb', 'v3_runtime.py', 'validate_v3.py', 'board_server.py'):
            archive.write(HERE/name, 'source/'+name)
    return target
