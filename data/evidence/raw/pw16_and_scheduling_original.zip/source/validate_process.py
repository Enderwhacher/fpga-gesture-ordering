"""Fixed-image 2x2 A/B: thread/process capture and CPU/verified FPGA classifier.

No ordering actions are sent. The real camera supplies background load only.
Includes detector, preprocess, classifier and top-k, excludes HTTP/UI latency.
"""
import hashlib,json,platform,runpy,statistics,sys,threading,time,traceback,types,uuid,zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
FIXED_SHA='213305d73f73cc254f8cc9b3b4c0c237812f474673c77eeb2d9256852570643f'
CASES=(('thread','cpu'),('process','cpu'),('process','fpga'),('thread','fpga'),
       ('thread','fpga'),('process','fpga'),('process','cpu'),('thread','cpu'))

def system_snapshot():
    result={'cpu_frequency_khz':{},'thermal_raw':{}}
    for key,pattern in (('cpu_frequency_khz','/sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq'),
                        ('thermal_raw','/sys/class/thermal/thermal_zone*/temp')):
        import glob
        for name in glob.glob(pattern):
            try:result[key][name]=int(Path(name).read_text().strip())
            except (OSError,ValueError):pass
    return result

def compare(actual,expected,atol=1e-4):
    import numpy as np
    if actual.shape!=expected.shape or not np.isfinite(actual).all() or not np.isfinite(expected).all():
        raise RuntimeError('Invalid comparison output')
    delta=np.abs(actual.astype(np.float64)-expected.astype(np.float64))
    if (delta>atol+1e-4*np.abs(expected)).any(): raise RuntimeError('Fixed-frame output mismatch')
    return float(delta.max()) if delta.size else 0.

class BackgroundCamera:
    """Use real application capture/preview paths; never start a second inference."""
    def __init__(self,cv,root,mode):
        from board_server import BoardRuntime
        self.camera=None;self.runtime=None;self.mode=mode
        fixture=types.SimpleNamespace(meta={'name':'Benchmark background only'})
        if mode=='thread': self.runtime=BoardRuntime(fixture,cv)
        elif mode=='process':
            from camera_process import CameraProcess
            self.camera=CameraProcess(root)
            self.cv=cv;self.fixture=fixture
        else: raise ValueError('Unknown background mode')
    def start(self):
        if self.camera is not None:
            from process_server import ProcessBoardRuntime
            self.camera.start()
            if self.camera.snapshot()['camera_threads']!=1: raise RuntimeError('Camera must use one thread')
            self.runtime=ProcessBoardRuntime(self.fixture,self.cv,self.camera)
        r=self.runtime;r.begin=time.monotonic()
        r.threads=[threading.Thread(target=r.capture_loop,daemon=True,name='ab-capture'),
                   threading.Thread(target=r.preview_loop,daemon=True,name='ab-preview')]
        for worker in r.threads:worker.start()
        deadline=time.monotonic()+30;progress=time.monotonic()+3
        while time.monotonic()<deadline:
            if r.error or r.preview_stream_error:raise RuntimeError(r.error or r.preview_stream_error)
            if r.capture_count>=2 and r.preview_encoded_count>=2:return
            if time.monotonic()>progress:print('Waiting for '+self.mode+' camera...',flush=True);progress=time.monotonic()+3
            time.sleep(.03)
        raise RuntimeError('A/B camera startup timeout')
    def snapshot(self):
        r=self.runtime
        if r is None:return {}
        return {'capture_count':r.capture_count,'preview_count':r.preview_encoded_count,
                'error':r.error,'preview_error':r.preview_stream_error,
                'camera_process':self.camera.snapshot() if self.camera is not None else None}
    def stop(self):
        r=self.runtime
        if r is not None:r.stop_event.set()
        child=self.camera.stop() if self.camera is not None else None
        alive=r.stop(timeout=3) if r is not None else []
        return dict(self.snapshot(),alive=bool(alive or (child and child.get('alive'))),
                    workers_still_alive=alive,forced_stop=bool(child and child.get('forced_stop')))

def measure(vision,frame):
    import numpy as np
    start=time.perf_counter();hands=np.asarray(vision.detector.infer(frame),dtype=np.float32).reshape(-1,19)
    detection=time.perf_counter()
    if not len(hands):raise RuntimeError('No hand in the saved benchmark image')
    before=int(getattr(vision.classifier,'fpga_completed_frames',0))
    logits=vision.classifier.logits(vision.classifier.preprocess(frame));top=vision.classifier.topk(logits,k=3)
    end=time.perf_counter();after=int(getattr(vision.classifier,'fpga_completed_frames',0))
    enabled=vision.accelerator is not None
    if enabled and after!=before+1:raise RuntimeError('No real FPGA completion for this classified frame')
    return dict(detector_ms=(detection-start)*1000,classifier_ms=(end-detection)*1000,
                pipeline_ms=(end-start)*1000,logits=logits.astype(float).tolist(),
                label=str(top[0][0]),score=float(top[0][1]),fpga_completed_delta=after-before,
                fpga_call_ms=float(vision.accelerator.last_timing['total_ms']) if enabled else None),hands,logits.copy()

def summarize(rows):
    summary={}
    for mode,backend in dict.fromkeys(CASES):
        selected=[r for r in rows if r['mode']==mode and r['backend']==backend]
        if not selected:raise RuntimeError('Missing comparison case')
        summary[mode+'_'+backend]={key:statistics.median(r[key] for r in selected)
            for key in ('detector_ms','classifier_ms','pipeline_ms')}
        summary[mode+'_'+backend]['samples']=len(selected)
    old=summary['thread_fpga']['pipeline_ms'];new=summary['process_fpga']['pipeline_ms']
    cpu=summary['process_cpu']['pipeline_ms']
    if min(old,new,cpu)<=0:raise RuntimeError('Invalid timing')
    return dict(summary=summary,process_reduction_percent=100*(1-new/old),process_speedup=old/new,
                fpga_reduction_in_process_percent=100*(1-new/cpu),
                combined_vs_thread_cpu_speedup=summary['thread_cpu']['pipeline_ms']/new,
                recommend_process_mode=new<=old*.90,noticeable_25percent_target_met=new<=old*.75)

def export_results(root='/home/xilinx/jupyter_notebooks'):
    for name in ('process_server','board_server'):
        module=sys.modules.get(name);runtime=getattr(module,'_active_runtime',None)
        if runtime is not None and any(t.is_alive() for t in runtime.threads):
            raise RuntimeError('Stop the server before packaging results')
    archive=HERE/'gesture_order_blocks56_process_v4_results.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for directory in ('results','logs'):
            for path in sorted((HERE/directory).rglob('*')):
                if path.is_file():z.write(path,path.relative_to(HERE).as_posix())
        for path in sorted(HERE.glob('*.py')):z.write(path,'source/'+path.name)
        for name in ('app_manifest.json','00_process_v4.ipynb'):
            z.write(HERE/name,'source/'+name)
        z.write(HERE/'inputs/fixed_frame.png','inputs/fixed_frame.png')
    print('RESULTS:',archive,flush=True);return archive

def run(root='/home/xilinx/jupyter_notebooks',samples_per_block=4):
    if type(samples_per_block) is not int or samples_per_block<3:raise ValueError('Use at least 3 samples per block')
    root=Path(root);folder=HERE/'results'/('ab_'+uuid.uuid4().hex[:12]);folder.mkdir(parents=True)
    report=dict(passed=False,error=None,cleanup_errors=[],samples=[],blocks=[],
        scope='Fixed real image; detector+preprocess+classification+top-k. 2x2 thread/process x CPU/FPGA, balanced reverse order. Real camera and preview background, no HTTP clients or UI time.',
        board_tested=True,script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    cv=background=reservation=None;visions={};previous_threads=None;restore_allowed=True;caught=None
    def save():(folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    try:
        if platform.system()!='Linux' or platform.machine().lower() not in ('aarch64','arm64'):raise RuntimeError('Run on PYNQ-ZU')
        runpy.run_path(str(HERE/'verify_remote_app.py'),run_name='process4_verify')
        from session_guard import exclusive_board_test
        from board_server import VisionBackend,check_camera_unused,load_cv
        guard=exclusive_board_test();guard.__enter__();reservation=guard
        check_camera_unused('/dev/video0');cv=load_cv(root);previous_threads=cv.getNumThreads()
        for backend in ('cpu','fpga'):
            print('Loading '+backend+' benchmark backend...',flush=True)
            visions[backend]=VisionBackend(root,root/'gesture4_model_v2',root/'gesture_block_accel_v1',backend,4)
        # Reuse the same detector object to avoid net-allocation/cache differences.
        visions['fpga'].detector=visions['cpu'].detector
        path=HERE/'inputs/fixed_frame.png'
        if hashlib.sha256(path.read_bytes()).hexdigest()!=FIXED_SHA:raise RuntimeError('Fixed image changed')
        frame=cv.imread(str(path))
        if frame is None or frame.shape!=(480,640,3):raise RuntimeError('Invalid fixed image')
        frame_hash=hashlib.sha256(frame.tobytes()).hexdigest()
        _,reference_hands,reference_logits=measure(visions['cpu'],frame)
        reference_hands=reference_hands.copy()
        report.update(frame_pixels_sha256=frame_hash,reference_logits=reference_logits.astype(float).tolist(),
                      parent_cv_threads=int(cv.getNumThreads()),hardware_release=visions['fpga'].meta['hardware_release'])
        for index,(mode,backend) in enumerate(CASES,1):
            print(f'AB_CASE {index}/{len(CASES)} | {mode} + {backend}',flush=True)
            block=dict(mode=mode,backend=backend,index=index);report['blocks'].append(block);save()
            background=BackgroundCamera(cv,root,mode)
            try:
                background.start();block['before']=background.snapshot()
                block['system_before']=system_snapshot();block_started=time.perf_counter()
                for i in range(samples_per_block+2):
                    row,hands,logits=measure(visions[backend],frame)
                    row['palm_max_abs_error']=compare(hands,reference_hands,1e-3)
                    row['logits_max_abs_error']=compare(logits,reference_logits)
                    if i<2:continue
                    row.update(mode=mode,backend=backend,block=index,sample=i-1);report['samples'].append(row)
                    print(f'  {i-1}/{samples_per_block}: {row["pipeline_ms"]:.2f} ms',flush=True)
                block['duration_seconds']=time.perf_counter()-block_started
                block['after']=background.snapshot();block['system_after']=system_snapshot()
                block['background_hz']={key:(block['after'][key]-block['before'][key])/block['duration_seconds']
                    for key in ('capture_count','preview_count')}
                if any(block['after'][key]<=block['before'][key] for key in ('capture_count','preview_count')):
                    raise RuntimeError('Camera/preview did not advance during the measurement')
            finally:
                status=background.stop();block['cleanup']=status
                if status.get('alive'):restore_allowed=False;raise RuntimeError('Camera workers still alive')
                background=None;save()
            if status.get('error') or status.get('preview_error') or status.get('forced_stop'):
                raise RuntimeError('Camera did not complete cleanly: '+str(status))
        if hashlib.sha256(frame.tobytes()).hexdigest()!=frame_hash:raise RuntimeError('Fixed image modified')
        report.update(summarize(report['samples']))
        report['process_background_quality_ok']=all(b['background_hz']['capture_count']>=10 and
            b['background_hz']['preview_count']>=8 for b in report['blocks'] if b['mode']=='process')
        report['recommend_process_mode']=report['recommend_process_mode'] and report['process_background_quality_ok']
        report['passed']=True
    except BaseException as error:
        caught=error;report['error']=dict(message=repr(error),traceback=traceback.format_exc())
    finally:
        if background is not None:
            try:
                status=background.stop()
                if status.get('alive'):restore_allowed=False;report['cleanup_errors'].append(status)
            except BaseException as error:restore_allowed=False;report['cleanup_errors'].append(repr(error))
        for vision in visions.values():
            try:vision.close()
            except BaseException as error:restore_allowed=False;report['cleanup_errors'].append(repr(error))
        if cv is not None and previous_threads is not None and restore_allowed:cv.setNumThreads(previous_threads)
        if reservation is not None:reservation.__exit__(None,None,None)
        report['kernel_restart_required']=not restore_allowed
        report['passed']=bool(report['passed'] and report['error'] is None and not report['cleanup_errors'])
        save();export_results(root)
        print('PROCESS4_AB_OK' if report['passed'] else 'PROCESS4_AB_FAILED',flush=True)
    if caught is not None:raise caught
    print(json.dumps(report['summary'],indent=2),flush=True)
    print('分进程+原FPGA / 原线程+原FPGA:',round(report['process_speedup'],3),'x',flush=True)
    print('25% 耗时下降目标:',report['noticeable_25percent_target_met'],flush=True)
    return report
