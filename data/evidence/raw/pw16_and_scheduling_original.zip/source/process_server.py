"""Board ordering service with a spawn camera process and one FPGA owner."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import threading
import time

from board_server import BoardRuntime,VisionBackend,check_camera_unused,food_thumbnails,make_handler
from camera_process import CameraProcess
import board_server as base_server

HERE=Path(__file__).resolve().parent
_active_runtime=None
_active_camera=None


class ProcessBoardRuntime(BoardRuntime):
    def __init__(self,backend,cv,camera,**kwargs):
        super().__init__(backend,cv,**kwargs)
        self.camera=camera
        snapshot=camera.snapshot()
        self.capture_base=snapshot['capture_count']; self.preview_base=snapshot['preview_count']
        self.capture_process_metrics=None

    def capture_loop(self):
        last=0
        try:
            with self.lock: self.camera_stage='WAITING FOR CAPTURE PROCESS'
            while not self.stop_event.is_set():
                item=self.camera.read_frame(last,not_before=self.begin)
                if item is None:
                    status=self.camera.snapshot()
                    if status['error'] or not status['alive']:
                        raise RuntimeError(status['error'] or 'Capture process exited')
                    self.stop_event.wait(.005); continue
                seq,captured,frame=item; last=seq
                with self.lock:
                    self.frame=frame; self.captured_at=captured; self.seq=seq
                    self.capture_count=max(0,seq-self.capture_base)
                    self.camera_stage='PROCESS STREAMING'
        except BaseException as error:
            if not self.stop_event.is_set(): self.fail('capture-process',error)

    def preview_loop(self):
        last=0
        try:
            while not self.stop_event.is_set():
                item=self.camera.read_preview(last,not_before=self.begin)
                if item is None:
                    status=self.camera.snapshot()
                    if status['preview_error']: raise RuntimeError(status['preview_error'])
                    self.stop_event.wait(.008); continue
                seq,captured,encoded,encode_ms,count=item; last=seq
                # No cv2 calls in this bridge: encoding stays in the child.
                with self.lock:
                    self.preview_stream=encoded; self.preview_stream_seq=seq
                    self.preview_stream_source=captured; self.preview_encode_ms=encode_ms
                    self.preview_encoded_count=max(0,count-self.preview_base)
        except Exception as error:
            with self.lock: self.preview_stream_error=f'{type(error).__name__}: {error}'
            print('Preview bridge failed:',self.preview_stream_error,flush=True)

    def check_health(self):
        super().check_health()
        if not self.stop_event.is_set():
            status=self.camera.snapshot()
            if status['error'] or not status['alive']:
                self.fail('capture-process',RuntimeError(status['error'] or 'Capture process exited'))

    def save_log(self,directory,reason,alive):
        path=super().save_log(directory,reason,alive)
        import json
        data=json.loads(path.read_text(encoding='utf-8'))
        data['capture_process']=self.capture_process_metrics or self.camera.snapshot()
        data['transport_note']='Two shared PS-RAM image slots, owned parent snapshots; not FPGA DMA double buffering.'
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
        return path


def run_board_server(root='/home/xilinx/jupyter_notebooks',model_dir=None,accel_dir=None,asset_dir=None,
                     host='0.0.0.0',port=8765,backend='fpga',camera_device='/dev/video0',
                     rotate_180=False,mirror=False,seconds=0,cv_threads=4):
    global _active_runtime,_active_camera
    if _active_runtime is not None and any(t.is_alive() for t in _active_runtime.threads):
        raise RuntimeError('Previous inference worker is alive; restart the Notebook kernel')
    if _active_camera is not None and not _active_camera.closed:
        raise RuntimeError('Previous capture process has not closed')
    root=Path(root); models=Path(model_dir or root/'gesture4_model_v2')
    accel=Path(accel_dir or root/('gesture_block_accel_v2' if backend=='fpga_v2' else 'gesture_block_accel_v1'))
    assets=Path(asset_dir or root/'gesture_order_demo_v2/assets')
    camera=vision=server=runtime=serving=None; reason='finished'
    try:
        check_camera_unused(camera_device)
        # Reserve HTTP before either camera startup or bitstream download.
        server=ThreadingHTTPServer((host,port),BaseHTTPRequestHandler); server.daemon_threads=True
        print('Starting separate camera process (OpenCV threads=1)...',flush=True)
        camera=CameraProcess(root,camera_device,rotate_180,mirror); _active_camera=camera
        camera.start()
        if camera.snapshot()['camera_threads']!=1:
            raise RuntimeError('Capture process must use one OpenCV thread')
        print('Camera ready; loading verified '+backend+' classifier...',flush=True)
        vision=VisionBackend(root,models,accel,backend,cv_threads)
        vision.meta.update(app_release='gesture_order_blocks56_process_v4',capture_process=True,
                           camera_cv_threads=1,camera_pid=camera.snapshot()['pid'])
        runtime=ProcessBoardRuntime(vision,vision.cv,camera,camera_device=camera_device,
                    rotate_180=rotate_180,mirror=mirror,assets=food_thumbnails(assets,vision.cv))
        server.RequestHandlerClass=make_handler(runtime)
        runtime.start(); _active_runtime=runtime; base_server._active_runtime=runtime
        serving=threading.Thread(target=server.serve_forever,name='order-http',daemon=True); serving.start()
        print('ORDER_BOARD_SERVER_READY port='+str(server.server_port),flush=True)
        print('BLOCKS56_PROCESS_V4 | inference threads='+str(cv_threads)+' | camera threads=1 | shared frames=2',flush=True)
        while not runtime.stop_event.wait(.2):
            runtime.check_health()
            if seconds and time.monotonic()-runtime.begin>=seconds: break
        if runtime.error: reason='error'; raise RuntimeError(runtime.error)
    except KeyboardInterrupt:
        reason='interrupted'; print('Stopping camera process/inference and saving logs...',flush=True)
    except BaseException:
        reason='error'; raise
    finally:
        if runtime is not None: runtime.stop_event.set()
        if server is not None:
            if serving is not None: server.shutdown()
            server.server_close()
        if serving is not None: serving.join(timeout=2)
        camera_status=None
        if camera is not None:
            try: camera_status=camera.stop()
            except BaseException as error:
                camera_status={'alive':True,'stop_error':repr(error)}
                if runtime is not None: runtime.fail('camera close',error)
        if runtime is not None and runtime.threads:
            runtime.capture_process_metrics=camera_status
            alive=runtime.stop()
            try: print('BOARD_LOG:',runtime.save_log(HERE/'logs',reason,alive),flush=True)
            except OSError as error: print('Cannot save board log:',error,flush=True)
            if alive or (camera_status and camera_status.get('alive')):
                print('Workers still alive; restart kernel before retrying:',alive,camera_status,flush=True)
            else: print('ORDER_BOARD_SERVER_STOPPED',flush=True)
        elif vision is not None: vision.close()
