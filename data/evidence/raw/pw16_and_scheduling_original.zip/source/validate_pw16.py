"""Same-input FPGA v1/v2 A/B with full-model logits and parameter-reload checks."""
import hashlib,importlib,json,platform,runpy,statistics,sys,time,traceback,uuid
from pathlib import Path
import numpy as np
from validate_process import compare,system_snapshot

HERE=Path(__file__).resolve().parent

def load_version(directory,version):
    name='blocks_runtime' if version=='v1' else 'blocks16_runtime'
    loaded=sys.modules.get(name)
    if loaded is not None and Path(loaded.__file__).resolve()!=(directory/(name+'.py')).resolve():
        raise RuntimeError('Different FPGA module cached; restart kernel')
    if str(directory) not in sys.path:sys.path.insert(0,str(directory))
    return importlib.import_module(name).make_fpga_classifier(directory)

def timed(function,*args):
    start=time.perf_counter();value=function(*args)
    return value,(time.perf_counter()-start)*1000

def summarize(rows):
    result={}
    for version in ('v1','v2'):
        selected=[r for r in rows if r['version']==version]
        if not selected:raise RuntimeError('Incomplete hardware comparison')
        result[version]={key:statistics.median(r[key] for r in selected)
            for key in ('kernel_with_transfer_ms','classifier_ms','cpu_blocks_ms','cpu_classifier_ms')}
        result[version]['samples']=len(selected)
        result[version]['cpu_to_fpga_blocks_speedup']=result[version]['cpu_blocks_ms']/result[version]['kernel_with_transfer_ms']
        result[version]['cpu_to_fpga_classifier_speedup']=result[version]['cpu_classifier_ms']/result[version]['classifier_ms']
    old=result['v1']['kernel_with_transfer_ms'];new=result['v2']['kernel_with_transfer_ms']
    return dict(summary=result,fpga_call_speedup=old/new,fpga_call_reduction_percent=100*(1-new/old),
        classifier_speedup=result['v1']['classifier_ms']/result['v2']['classifier_ms'],
        recommend_new_hardware=new<=old*.95 and result['v2']['classifier_ms']<=result['v1']['classifier_ms']*1.03)

def run(root='/home/xilinx/jupyter_notebooks',repeats=8):
    if type(repeats) is not int or repeats<6:raise ValueError('At least six repeats required')
    root=Path(root);folder=HERE/'results'/('pw16_'+uuid.uuid4().hex[:12]);folder.mkdir(parents=True)
    report=dict(passed=False,board_tested=True,samples=[],phases=[],numeric_checks=[],error=None,cleanup_errors=[],
                scope='Same original FP32 model and saved tensors. v1/v2/v2/v1 at four CPU threads; each phase loads one overlay. Includes paired CPU block and full-network logits references. Classifier time excludes preprocessing/top-k. Excludes camera, detector, network and UI latency.')
    cv=owner=reservation=None;previous_threads=None;caught=None
    def save():(folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    try:
        if platform.system()!='Linux' or platform.machine().lower() not in ('aarch64','arm64'):raise RuntimeError('Run on PYNQ-ZU')
        runpy.run_path(str(HERE/'verify_remote_app.py'),run_name='pw16_app_verify')
        from board_server import check_camera_unused,load_cv
        from session_guard import exclusive_board_test
        guard=exclusive_board_test();guard.__enter__();reservation=guard
        check_camera_unused('/dev/video0')
        cv=load_cv(root);previous_threads=cv.getNumThreads();cv.setNumThreads(4)
        paths={'v1':root/'gesture_block_accel_v1','v2':root/'gesture_block_accel_v2'}
        for version,directory in paths.items():runpy.run_path(str(directory/'board/verify_package.py'),run_name='pw16_verify_'+version)
        report['same_model_artifacts_sha256']={}
        for relative in ('source/hagrid_mobilenetv3_large.onnx','export/params/block0.bin','export/params/block1.bin',
                         'export/models/prefix.onnx','export/models/blocks.onnx','export/models/suffix.onnx'):
            hashes={version:hashlib.sha256((directory/relative).read_bytes()).hexdigest() for version,directory in paths.items()}
            if len(set(hashes.values()))!=1:raise RuntimeError('Old/new model artifacts differ: '+relative)
            report['same_model_artifacts_sha256'][relative]=hashes['v1']
        source=paths['v2'];frame=np.load(source/'export/cases/real_frame/input.npy',allow_pickle=False)
        blob=np.load(source/'export/cases/real_frame/model_input.npy',allow_pickle=False)
        expected_logits=np.load(source/'export/cases/real_frame/model_logits.npy',allow_pickle=False).reshape(-1)
        expected_block=np.load(source/'export/cases/real_frame/golden_output.npy',allow_pickle=False)
        cpu_blocks=cv.dnn.readNetFromONNX(str(source/'export/models/blocks.onnx'))
        cpu_full=cv.dnn.readNetFromONNX(str(source/'source/hagrid_mobilenetv3_large.onnx'))
        for net in (cpu_blocks,cpu_full):
            net.setPreferableBackend(cv.dnn.DNN_BACKEND_OPENCV);net.setPreferableTarget(cv.dnn.DNN_TARGET_CPU)
        def cpu_forward(net,value):net.setInput(value);return net.forward()
        report['frame_tensor_sha256']=hashlib.sha256(frame.tobytes()).hexdigest()
        report['model_input_sha256']=hashlib.sha256(blob.tobytes()).hexdigest()
        report['cv_threads']=int(cv.getNumThreads())
        for index,version in enumerate(('v1','v2','v2','v1'),1):
            print(f'PW16_CASE {index}/4 | {version}',flush=True)
            classifier,owner=load_version(paths[version],version)
            phase=dict(index=index,version=version,bitfile=str(owner.overlay.bitfile_name),system_before=system_snapshot());report['phases'].append(phase)
            try:
                names=(source/'export/case_list.txt').read_text().splitlines()
                for name in names:
                    x=np.load(source/f'export/cases/{name}/input.npy',allow_pickle=False)
                    expected=np.load(source/f'export/cases/{name}/golden_output.npy',allow_pickle=False)
                    actual=owner.run(x)
                    report['numeric_checks'].append(dict(phase=index,version=version,case=name,max_abs_error=compare(actual,expected)))
                parameters=[np.fromfile(source/f'export/params/block{bank}.bin',dtype='<f4') for bank in (0,1)]
                for bank,p in enumerate(parameters):owner.load_parameters(bank,np.zeros_like(p))
                report['numeric_checks'].append(dict(phase=index,version=version,case='reload_zero_identity',
                    max_abs_error=compare(owner.run(frame),frame)))
                for bank,p in enumerate(parameters):owner.load_parameters(bank,p)
                for i in range(repeats+2):
                    before=classifier.fpga_completed_frames
                    work=(('cpu_blocks',cpu_forward,(cpu_blocks,frame)),('kernel_with_transfer',owner.run,(frame,)),
                          ('cpu_classifier',cpu_forward,(cpu_full,blob)),('classifier',classifier.logits,(blob,)))
                    values={};times={}
                    for key,function,args in (work if i%2==0 else work[::-1]):
                        values[key],times[key+'_ms']=timed(function,*args)
                    # Golden comparisons and report bookkeeping are outside timed sections.
                    kernel_error=compare(values['kernel_with_transfer'],expected_block)
                    error=compare(values['classifier'].reshape(-1),expected_logits)
                    cpu_block_error=compare(values['cpu_blocks'],expected_block)
                    cpu_logits_error=compare(values['cpu_classifier'].reshape(-1),expected_logits)
                    if classifier.fpga_completed_frames!=before+1:raise RuntimeError('Missing FPGA classification completion')
                    if i<2:continue
                    report['samples'].append(dict(phase=index,version=version,sample=i-1,**times,
                        kernel_max_abs_error=kernel_error,logits_max_abs_error=error,
                        cpu_blocks_max_abs_error=cpu_block_error,cpu_logits_max_abs_error=cpu_logits_error,
                        logits=values['classifier'].reshape(-1).astype(float).tolist(),
                        split_timing=dict(classifier.last_split_timing)))
                phase['completed_kernel_commands']=owner.completed_frames
                phase['system_after']=system_snapshot()
            finally:
                owner.close();owner=None;save()
        report.update(summarize(report['samples']));report['passed']=True
    except BaseException as error:
        caught=error;report['error']=dict(message=repr(error),traceback=traceback.format_exc())
    finally:
        if owner is not None:
            try:owner.close()
            except BaseException as error:report['cleanup_errors'].append(repr(error))
        if cv is not None and previous_threads is not None:cv.setNumThreads(previous_threads)
        if reservation is not None:reservation.__exit__(None,None,None)
        report['kernel_restart_required']=caught is not None
        report['passed']=bool(report['passed'] and report['error'] is None and not report['cleanup_errors'])
        save();print('PW16_VALIDATION_OK' if report['passed'] else 'PW16_VALIDATION_FAILED',flush=True)
    if caught is not None:raise caught
    print(json.dumps(report['summary'],indent=2),flush=True)
    print('新/旧 FPGA 调用提速:',round(report['fpga_call_speedup'],3),'x',flush=True)
    return report
