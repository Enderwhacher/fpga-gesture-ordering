"""Read-only checks before downloading the already verified computation overlay."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import runpy
import sys

HERE=Path(__file__).resolve().parent
MODEL_SHA='568660b57f4cd01cacae40d64df9124e9194c7fbcc42f8245839eb691badf741'


def preflight(root='/home/xilinx/jupyter_notebooks',model_dir=None,accel_dir=None,asset_dir=None,camera_device='/dev/video0',cv_threads=4):
    root=Path(root); models=Path(model_dir or root/'gesture4_model_v2')
    accel=Path(accel_dir or root/'gesture_block_accel_v1')
    assets=Path(asset_dir or root/'gesture_order_demo_v2/assets')
    runpy.run_path(str(HERE/'verify_remote_app.py'),run_name='remote_app_check')
    for path in (accel/'package_manifest.json',root/'gesture_assets/mp_palmdet.py',
                 root/'gesture_assets/palm_detection_mediapipe_2023feb.onnx',
                 models/'model_meta.json',models/'hagrid_runtime.py',models/'hagrid_mobilenetv3_large.onnx',Path(camera_device)):
        if not path.exists(): raise FileNotFoundError('Missing existing deployment file/device: '+str(path))
    runpy.run_path(str(accel/'board/verify_package.py'),run_name='original_compute_release_check')
    runpy.run_path(str(root/'gesture_block_accel_v2/board/verify_package.py'),run_name='pw16_compute_release_check')
    from board_server import check_camera_unused,load_cv
    from order_core import LABELS,MENU
    # Preflight never changes process-global OpenCV thread settings.
    from session_guard import exclusive_board_test
    with exclusive_board_test():
        check_camera_unused(camera_device)
        cv=load_cv(root)
    if type(cv_threads) is not int or cv_threads not in (2,4): raise ValueError('cv_threads must be 2 or 4')
    meta=json.loads((models/'model_meta.json').read_text(encoding='utf-8'))
    actual=hashlib.sha256((models/'hagrid_mobilenetv3_large.onnx').read_bytes()).hexdigest()
    if actual!=MODEL_SHA or actual!=meta['model_sha256']:
        raise RuntimeError('This app targets the verified HaGRID v2 model; requested ONNX differs')
    fingerprints={}
    for path,expected in ((models/'hagrid_runtime.py','065f0ba1f30908b223d148178a22bd29c7eeaae58ff58a2b1611b529a298d24f'),
                         (models/'model_meta.json','eb1bb16df09fb57d8a29e98b6789a482fa4e292e98a5febb6afea8e03ae6b15c'),
                         (root/'gesture_assets/palm_detection_mediapipe_2023feb.onnx','78ff51c38496b7fc8b8ebdb6cc8c1abb02fa6c38427c6848254cdaba57fcce7c')):
        fingerprints[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
        if fingerprints[str(path)]!=expected:raise RuntimeError('Verified model/preprocessing file differs: '+str(path))
    if tuple(meta['labels'])!=LABELS: raise RuntimeError('Gesture class order differs')
    record={'python':sys.version,'opencv':cv.__version__,'pynq':importlib.metadata.version('pynq'),'requested_cv_threads':cv_threads,
        'model_sha256':actual,'fingerprints':fingerprints,'root':str(root),'model_dir':str(models),'accel_dir':str(accel),
        'asset_dir':str(assets),'camera_device':camera_device,
        'assets_present':{item['image']:(assets/item['image']).is_file() for item in MENU},
        'checks_passed':True,'hardware_downloaded_by_preflight':False}
    (HERE/'logs').mkdir(exist_ok=True)
    (HERE/'logs/preflight.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('REMOTE_ORDER_PREFLIGHT_OK | OpenCV',cv.__version__,'| requested threads',cv_threads,'| PYNQ',record['pynq'])
    print('Existing computation package checked. No bitstream loaded in this check.')
    return record

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',default='/home/xilinx/jupyter_notebooks')
    parser.add_argument('--model-dir'); parser.add_argument('--accel-dir'); parser.add_argument('--asset-dir')
    parser.add_argument('--camera-device',default='/dev/video0')
    parser.add_argument('--cv-threads',type=int,choices=(2,4),default=4)
    preflight(**vars(parser.parse_args()))
