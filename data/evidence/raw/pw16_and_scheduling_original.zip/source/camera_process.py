"""Spawn-only camera/preview transport. This module never imports PYNQ.

Two PS RAM image slots are protected separately. Per-slot sequence/timestamp
travel under the slot lock, so a late reader can never label new pixels with
an old sequence. Reads return owned arrays; there is no unbounded frame queue.
"""
import base64
from contextlib import contextmanager
import multiprocessing as mp
from pathlib import Path
import time

HEIGHT=480
WIDTH=640
FRAME_BYTES=HEIGHT*WIDTH*3
PREVIEW_BYTES=64*1024
ERROR_BYTES=2048


@contextmanager
def locked(lock,timeout=.5):
    if not lock.acquire(timeout=timeout): raise RuntimeError('Camera transport lock timeout')
    try: yield
    finally: lock.release()


def make_shared(ctx):
    return {'frames':ctx.RawArray('B',2*FRAME_BYTES),'slot_seq':ctx.RawArray('Q',2),
            'slot_time':ctx.RawArray('d',2),'slot_locks':[ctx.Lock(),ctx.Lock()],
            'published_slot':ctx.RawValue('i',0),'state_lock':ctx.Lock(),
            'capture_count':ctx.RawValue('Q',0),'preview_count':ctx.RawValue('Q',0),
            'camera_threads':ctx.RawValue('i',0),'ready':ctx.RawValue('i',0),
            'read_ms':ctx.RawValue('d',0),'last_capture':ctx.RawValue('d',0),
            'preview':ctx.RawArray('B',PREVIEW_BYTES),'preview_size':ctx.RawValue('i',0),
            'preview_seq':ctx.RawValue('Q',0),'preview_source':ctx.RawValue('d',0),
            'preview_encode_ms':ctx.RawValue('d',0),'preview_lock':ctx.Lock(),
            'error':ctx.RawArray('B',ERROR_BYTES),'preview_error':ctx.RawArray('B',ERROR_BYTES),
            'error_lock':ctx.Lock(),'stop':ctx.Event()}


def write_error(shared,message,preview=False):
    data=str(message).encode('utf-8',errors='replace')[:ERROR_BYTES-1]
    with locked(shared['error_lock']):
        target=shared['preview_error' if preview else 'error']
        target[:]=b'\0'*ERROR_BYTES
        target[:len(data)]=data


def publish_frame(shared,frame,seq,captured):
    import numpy as np
    if frame.shape!=(HEIGHT,WIDTH,3) or frame.dtype!=np.uint8:
        raise ValueError('Camera frame must be uint8 BGR 480x640x3')
    with locked(shared['state_lock']): slot=1-shared['published_slot'].value
    with locked(shared['slot_locks'][slot]):
        pixels=np.frombuffer(shared['frames'],dtype=np.uint8).reshape(2,HEIGHT,WIDTH,3)
        pixels[slot]=frame
        shared['slot_seq'][slot]=seq
        shared['slot_time'][slot]=captured
    with locked(shared['state_lock']):
        shared['published_slot'].value=slot
        shared['capture_count'].value=seq
        shared['last_capture'].value=captured
        shared['ready'].value=1


def publish_preview(shared,encoded,seq,captured,encode_ms):
    if not isinstance(encoded,bytes) or len(encoded)>PREVIEW_BYTES:
        raise ValueError('Invalid or oversized preview')
    with locked(shared['preview_lock']):
        shared['preview'][:len(encoded)]=encoded
        shared['preview_size'].value=len(encoded)
        shared['preview_seq'].value=seq
        shared['preview_source'].value=captured
        shared['preview_encode_ms'].value=encode_ms
        shared['preview_count'].value+=1


def camera_worker(shared,config):
    # Spawn creates a fresh interpreter. Configure only this process's OpenCV;
    # no parent ML models, accelerator handles or DMA buffers are passed here.
    cap=None
    try:
        import sys
        runtime=Path(config['root'])/'gesture_runtime_cv410'
        if not runtime.is_dir(): raise RuntimeError('Missing OpenCV 4.10 runtime')
        sys.path.insert(0,str(runtime))
        import cv2
        import re
        if tuple(map(int,re.findall(r'\d+',cv2.__version__)[:2]))<(4,10):
            raise RuntimeError('Capture process requires OpenCV 4.10 or later')
        cv2.setNumThreads(1)
        with locked(shared['state_lock']): shared['camera_threads'].value=int(cv2.getNumThreads())
        cap=cv2.VideoCapture(config['device'],cv2.CAP_V4L2)
        if not cap.isOpened(): raise RuntimeError('Cannot open camera in capture process')
        for prop,value in ((cv2.CAP_PROP_FOURCC,cv2.VideoWriter_fourcc(*'MJPG')),
                           (cv2.CAP_PROP_FRAME_WIDTH,WIDTH),(cv2.CAP_PROP_FRAME_HEIGHT,HEIGHT),
                           (cv2.CAP_PROP_FPS,30)):
            cap.set(prop,value)
        seq=0; deadline=time.monotonic()+25; next_preview=time.monotonic(); preview_failed=False
        while not shared['stop'].is_set():
            begin=time.monotonic(); ok,frame=cap.read(); captured=time.monotonic()
            if shared['stop'].is_set(): break
            if not ok or frame is None:
                if seq==0 and captured<deadline:
                    shared['stop'].wait(.05); continue
                raise RuntimeError('Capture process camera read failed')
            if frame.shape[:2]!=(HEIGHT,WIDTH): frame=cv2.resize(frame,(WIDTH,HEIGHT))
            if config['rotate_180']: frame=cv2.rotate(frame,cv2.ROTATE_180)
            if config['mirror']: frame=cv2.flip(frame,1)
            seq+=1; publish_frame(shared,frame,seq,captured)
            with locked(shared['state_lock']): shared['read_ms'].value=(captured-begin)*1000
            now=time.monotonic()
            if not preview_failed and now>=next_preview:
                started=time.monotonic()
                try:
                    thumbnail=cv2.resize(frame,(160,120),interpolation=cv2.INTER_AREA)
                    ok,data=cv2.imencode('.jpg',thumbnail,[cv2.IMWRITE_JPEG_QUALITY,75])
                    if not ok: raise RuntimeError('Cannot encode preview')
                    publish_preview(shared,base64.b64encode(data.tobytes()),seq,captured,(time.monotonic()-started)*1000)
                except Exception as error:
                    preview_failed=True; write_error(shared,f'{type(error).__name__}: {error}',preview=True)
                # Advance by periods rather than resetting the deadline on every
                # camera frame; this keeps ~20 Hz with a ~30 Hz camera source.
                next_preview=max(next_preview+.05,now+.001)
    except BaseException as error:
        try: write_error(shared,f'{type(error).__name__}: {error}')
        except Exception: pass
    finally:
        if cap is not None: cap.release()


class CameraProcess:
    def __init__(self,root,device='/dev/video0',rotate_180=False,mirror=False,*,worker_target=None):
        self.ctx=mp.get_context('spawn'); self.shared=make_shared(self.ctx)
        self.config={'root':str(Path(root).resolve()),'device':device,
                     'rotate_180':bool(rotate_180),'mirror':bool(mirror)}
        self.worker_target=worker_target or camera_worker
        self.process=None; self.closed=False; self.forced_stop=False; self._last_status={}

    def start(self,timeout=30.):
        if self.closed or self.process is not None: raise RuntimeError('Capture process cannot be started twice or reused after close')
        self.process=self.ctx.Process(target=self.worker_target,args=(self.shared,self.config),name='gesture-camera',daemon=True)
        self.process.start(); deadline=time.monotonic()+timeout
        try:
            while time.monotonic()<deadline:
                status=self.snapshot()
                if status['error']: raise RuntimeError(status['error'])
                if status['ready'] and status['preview_count']>0: return
                if not self.process.is_alive(): raise RuntimeError('Capture process exited before its first frame/preview')
                time.sleep(.03)
            raise RuntimeError('Capture process startup timeout')
        except BaseException:
            self.stop(); raise

    def snapshot(self):
        with locked(self.shared['state_lock']):
            result={name:self.shared[name].value for name in ('capture_count','last_capture','read_ms','ready','camera_threads')}
        with locked(self.shared['preview_lock']):
            result.update(preview_count=self.shared['preview_count'].value,preview_seq=self.shared['preview_seq'].value)
        with locked(self.shared['error_lock']):
            for name in ('error','preview_error'):
                result[name]=bytes(self.shared[name]).split(b'\0',1)[0].decode('utf-8',errors='replace') or None
        result.update(pid=self.process.pid if self.process is not None else None,
                      alive=bool(self.process is not None and self.process.pid is not None and self.process.is_alive()),
                      forced_stop=self.forced_stop)
        self._last_status=result
        return result

    def read_frame(self,after_seq=0,not_before=0.):
        import numpy as np
        with locked(self.shared['state_lock']): slot=self.shared['published_slot'].value
        with locked(self.shared['slot_locks'][slot]):
            seq=int(self.shared['slot_seq'][slot]); captured=float(self.shared['slot_time'][slot])
            if seq<=after_seq or captured<not_before: return None
            frame=np.frombuffer(self.shared['frames'],dtype=np.uint8).reshape(2,HEIGHT,WIDTH,3)[slot].copy()
        return seq,captured,frame

    def read_preview(self,after_seq=0,not_before=0.):
        with locked(self.shared['preview_lock']):
            seq=int(self.shared['preview_seq'].value); captured=float(self.shared['preview_source'].value)
            if seq<=after_seq or captured<not_before: return None
            size=self.shared['preview_size'].value
            encoded=bytes(self.shared['preview'][:size]).decode('ascii')
            return seq,captured,encoded,float(self.shared['preview_encode_ms'].value),int(self.shared['preview_count'].value)

    def stop(self,timeout=5.):
        if self.closed: return dict(self._last_status)
        self.shared['stop'].set()
        if self.process is not None and self.process.pid is not None:
            self.process.join(timeout)
            if self.process.is_alive():
                self.forced_stop=True; self.process.terminate(); self.process.join(2)
            if self.process.is_alive(): self.process.kill(); self.process.join(2)
        try: status=self.snapshot()
        except RuntimeError:
            status=dict(self._last_status,forced_stop=self.forced_stop,metadata_lock_unavailable=True)
        status['alive']=bool(self.process is not None and self.process.pid is not None and self.process.is_alive())
        self.closed=True; self._last_status=status
        if status['alive']: raise RuntimeError('Camera process did not exit')
        return dict(status)
