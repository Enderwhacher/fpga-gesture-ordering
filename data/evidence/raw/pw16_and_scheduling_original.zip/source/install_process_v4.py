"""Install a separate process-v3 folder; never overwrite the validated app."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import uuid
import zipfile

PACKAGE = 'gesture_order_blocks56_process_v4'


def install(root='/home/xilinx/jupyter_notebooks', archive=None):
    root = Path(root).resolve()
    target = (root/PACKAGE).resolve()
    if not target.is_relative_to(root) or target.parent != root:
        raise RuntimeError('Invalid installation path')
    archive = Path(archive or root/(PACKAGE+'.zip'))
    with zipfile.ZipFile(archive) as z:
        if len(z.namelist()) != len(set(z.namelist())):
            raise RuntimeError('Duplicate archive members')
        manifest_data = z.read('release_manifest.json')
        manifest = json.loads(manifest_data)
        if manifest['package'] != PACKAGE:
            raise RuntimeError('Unexpected package')
        expected = manifest['sha256']
        if set(z.namelist()) != set(expected) | {'release_manifest.json'}:
            raise RuntimeError('Archive and manifest file lists differ')
        payload = {}
        for name, sha in expected.items():
            rel = PurePosixPath(name)
            if rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name:
                raise RuntimeError('Unsafe archive path')
            data = z.read(name)
            if hashlib.sha256(data).hexdigest() != sha:
                raise RuntimeError('Archive hash mismatch: '+name)
            payload[name] = data
        payload['release_manifest.json'] = manifest_data
    if target.exists():
        for name, data in payload.items():
            path = (target/name).resolve()
            if not path.is_relative_to(target) or not path.is_file():
                raise RuntimeError('Existing process-v3 files differ. Keep this folder and install into a clean root; no files overwritten.')
            if path.suffix != '.ipynb' and path.read_bytes() != data:
                raise RuntimeError('Existing process-v3 files differ. Keep this folder and install into a clean root; no files overwritten.')
        print('BLOCKS56_PROCESS_V4_ALREADY_INSTALLED:', target, flush=True)
        return target
    # New files go into a temporary sibling and become visible together.
    stage = root/('.blocks56_process_v4_install_'+uuid.uuid4().hex[:12])
    stage.mkdir()
    try:
        for name, data in payload.items():
            path = (stage/name).resolve()
            if not path.is_relative_to(stage.resolve()):
                raise RuntimeError('Staging path escaped its folder')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        stage.rename(target)
    except BaseException:
        print('Installation stopped; incomplete files remain only in:', stage, flush=True)
        raise
    print('BLOCKS56_PROCESS_V4_INSTALLED:', target, flush=True)
    print('The original applications, models and FPGA files were not overwritten.', flush=True)
    return target


if __name__ == '__main__':
    install()
