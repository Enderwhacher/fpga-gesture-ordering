//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Sat Oct 31 16:53:14 2026
//Host        : ljh159 running 64-bit major release  (build 9200)
//Command     : generate_target gblock_wrapper.bd
//Design      : gblock_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module gblock_wrapper
   ();


  gblock gblock_i
       ();
endmodule
