
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [11:0] axis_block_sigs;
wire [11:0] inst_idle_sigs;
wire [0:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~s_axis_TDATA_blk_n;
assign axis_block_sigs[1] = ~m_axis_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_397_9_VITIS_LOOP_398_10_fu_3070.s_axis_TDATA_blk_n;
assign axis_block_sigs[3] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_428_15_VITIS_LOOP_429_16_fu_3134.m_axis_TDATA_blk_n;
assign axis_block_sigs[4] = ~grp_read_pw_fu_3458.grp_read_pw_Pipeline_VITIS_LOOP_67_1_VITIS_LOOP_68_2_fu_146.s_axis_TDATA_blk_n;
assign axis_block_sigs[5] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_363_1_VITIS_LOOP_364_2_fu_3538.s_axis_TDATA_blk_n;
assign axis_block_sigs[6] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_369_3_fu_3651.s_axis_TDATA_blk_n;
assign axis_block_sigs[7] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_374_4_fu_3666.s_axis_TDATA_blk_n;
assign axis_block_sigs[8] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_378_5_fu_3695.s_axis_TDATA_blk_n;
assign axis_block_sigs[9] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_382_6_fu_3716.s_axis_TDATA_blk_n;
assign axis_block_sigs[10] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_386_7_fu_3731.s_axis_TDATA_blk_n;
assign axis_block_sigs[11] = ~grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_390_8_fu_3746.s_axis_TDATA_blk_n;

assign inst_block_sigs[0] = 1'b0;

assign inst_idle_sigs[0] = 1'b0;
assign inst_idle_sigs[1] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_397_9_VITIS_LOOP_398_10_fu_3070.ap_idle;
assign inst_idle_sigs[2] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_428_15_VITIS_LOOP_429_16_fu_3134.ap_idle;
assign inst_idle_sigs[3] = grp_read_pw_fu_3458.ap_idle;
assign inst_idle_sigs[4] = grp_read_pw_fu_3458.grp_read_pw_Pipeline_VITIS_LOOP_67_1_VITIS_LOOP_68_2_fu_146.ap_idle;
assign inst_idle_sigs[5] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_363_1_VITIS_LOOP_364_2_fu_3538.ap_idle;
assign inst_idle_sigs[6] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_369_3_fu_3651.ap_idle;
assign inst_idle_sigs[7] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_374_4_fu_3666.ap_idle;
assign inst_idle_sigs[8] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_378_5_fu_3695.ap_idle;
assign inst_idle_sigs[9] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_382_6_fu_3716.ap_idle;
assign inst_idle_sigs[10] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_386_7_fu_3731.ap_idle;
assign inst_idle_sigs[11] = grp_gesture_blocks56_axis_Pipeline_VITIS_LOOP_390_8_fu_3746.ap_idle;

gesture_blocks56_axis_hls_deadlock_idx0_monitor gesture_blocks56_axis_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
