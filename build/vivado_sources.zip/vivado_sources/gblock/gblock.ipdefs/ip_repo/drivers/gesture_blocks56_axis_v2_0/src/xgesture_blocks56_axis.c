// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xgesture_blocks56_axis.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGesture_blocks56_axis_CfgInitialize(XGesture_blocks56_axis *InstancePtr, XGesture_blocks56_axis_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XGesture_blocks56_axis_Start(XGesture_blocks56_axis *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL) & 0x80;
    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XGesture_blocks56_axis_IsDone(XGesture_blocks56_axis *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XGesture_blocks56_axis_IsIdle(XGesture_blocks56_axis *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XGesture_blocks56_axis_IsReady(XGesture_blocks56_axis *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XGesture_blocks56_axis_EnableAutoRestart(XGesture_blocks56_axis *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XGesture_blocks56_axis_DisableAutoRestart(XGesture_blocks56_axis *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_AP_CTRL, 0);
}

void XGesture_blocks56_axis_InterruptGlobalEnable(XGesture_blocks56_axis *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_GIE, 1);
}

void XGesture_blocks56_axis_InterruptGlobalDisable(XGesture_blocks56_axis *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_GIE, 0);
}

void XGesture_blocks56_axis_InterruptEnable(XGesture_blocks56_axis *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_IER);
    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_IER, Register | Mask);
}

void XGesture_blocks56_axis_InterruptDisable(XGesture_blocks56_axis *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_IER);
    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_IER, Register & (~Mask));
}

void XGesture_blocks56_axis_InterruptClear(XGesture_blocks56_axis *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGesture_blocks56_axis_WriteReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_ISR, Mask);
}

u32 XGesture_blocks56_axis_InterruptGetEnabled(XGesture_blocks56_axis *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_IER);
}

u32 XGesture_blocks56_axis_InterruptGetStatus(XGesture_blocks56_axis *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGesture_blocks56_axis_ReadReg(InstancePtr->Control_BaseAddress, XGESTURE_BLOCKS56_AXIS_CONTROL_ADDR_ISR);
}

