// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xgesture_blocks56_axis.h"

extern XGesture_blocks56_axis_Config XGesture_blocks56_axis_ConfigTable[];

#ifdef SDT
XGesture_blocks56_axis_Config *XGesture_blocks56_axis_LookupConfig(UINTPTR BaseAddress) {
	XGesture_blocks56_axis_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XGesture_blocks56_axis_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XGesture_blocks56_axis_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XGesture_blocks56_axis_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGesture_blocks56_axis_Initialize(XGesture_blocks56_axis *InstancePtr, UINTPTR BaseAddress) {
	XGesture_blocks56_axis_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGesture_blocks56_axis_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGesture_blocks56_axis_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XGesture_blocks56_axis_Config *XGesture_blocks56_axis_LookupConfig(u16 DeviceId) {
	XGesture_blocks56_axis_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGESTURE_BLOCKS56_AXIS_NUM_INSTANCES; Index++) {
		if (XGesture_blocks56_axis_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGesture_blocks56_axis_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGesture_blocks56_axis_Initialize(XGesture_blocks56_axis *InstancePtr, u16 DeviceId) {
	XGesture_blocks56_axis_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGesture_blocks56_axis_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGesture_blocks56_axis_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

