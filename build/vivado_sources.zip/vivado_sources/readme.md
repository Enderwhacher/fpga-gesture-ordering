# Vivado 源工程摘录

从原 PW16 v2 完整工程归档逐字节提取 gblock.xpr、gblock.srcs、gblock.ipdefs 和系统 wrapper。
保留 BD、IP 仓库与源文件，去掉综合、实现、缓存和大体积自动生成产品。
这是源码副本，不包含已布线设计检查点，不能直接 open_run impl_1 查看原布线结果。
XPR 中原运行状态与旧机器路径是归档遗留字段，不代表本精简目录已经综合或可直接打开所有运行结果。
需要重新生成输出产品并核对本地路径；推荐从 hardware/gesture_block_accel_v2/vivado/build.tcl 及配套工具重建。
本次仅提取与核对文件，未用 Vivado 重新打开或综合这份精简副本。
已验证的部署 bit/hwh 仍在 hardware/gesture_block_accel_v2/overlay，不必重建才能运行现有演示。
